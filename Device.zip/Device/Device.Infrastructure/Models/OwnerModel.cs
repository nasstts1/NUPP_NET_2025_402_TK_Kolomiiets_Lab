﻿using System;
using System.Collections.Generic;

namespace Devices.Infrastructure.Models
{
    public class OwnerModel
    {
        public Guid Id { get; set; }

        public string FullName { get; set; }
        public string ContactEmail { get; set; }

        public ICollection<DeviceModel> Devices { get; set; } = new List<DeviceModel>();
    }
}