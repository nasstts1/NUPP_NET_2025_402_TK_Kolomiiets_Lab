﻿using System.ComponentModel.DataAnnotations.Schema;
using Devices.Infrastructure.Models;

namespace Devices.Infrastructure.Models
{
    [Table("Laptops")]
    public class LaptopModel : DeviceModel
    {
        public int RamGB { get; set; }
        public string ProcessorBrand { get; set; } = string.Empty;

    }
}
