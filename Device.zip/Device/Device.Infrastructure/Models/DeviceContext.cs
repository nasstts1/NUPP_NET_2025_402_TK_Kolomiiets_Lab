﻿using Microsoft.EntityFrameworkCore;
using Devices.Infrastructure.Models;
using System;
using System.Linq;

namespace Devices.Infrastructure
{
    public class DeviceContext : DbContext
    {
        public DbSet<DeviceModel> Devices { get; set; }
        public DbSet<SmartphoneModel> Smartphones { get; set; }
        public DbSet<LaptopModel> Laptops { get; set; }
        public DbSet<OwnerModel> Owners { get; set; }
        public DbSet<SpecificationModel> Specifications { get; set; }

        public DeviceContext(DbContextOptions<DeviceContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<DeviceModel>().ToTable("Devices");
            modelBuilder.Entity<SmartphoneModel>().ToTable("Smartphones");
            modelBuilder.Entity<LaptopModel>().ToTable("Laptops");

            modelBuilder.Entity<OwnerModel>()
                .HasMany(o => o.Devices)
                .WithOne(d => d.Owner)
                .HasForeignKey(d => d.OwnerId)
                .IsRequired();

            modelBuilder.Entity<SpecificationModel>()
                .HasKey(s => s.DeviceId);

            modelBuilder.Entity<SpecificationModel>()
                .HasOne(s => s.Device)
                .WithOne() 
                .HasForeignKey<SpecificationModel>(s => s.DeviceId);


            var owner1Id = Guid.Parse("A1A1A1A1-A1A1-41A1-A1A1-A1A1A1A1A1A1");
            var owner2Id = Guid.Parse("B2B2B2B2-B2B2-42B2-B2B2-B2B2B2B2B2B2");
            var smartphoneId = Guid.Parse("C3C3C3C3-C3C3-43C3-C3C3-C3C3C3C3C3C3");
            var laptopId = Guid.Parse("D4D4D4D4-D4D4-44D4-D4D4-D4D4D4D4D4D4");

            modelBuilder.Entity<OwnerModel>().HasData(
                new OwnerModel { Id = owner1Id, FullName = "Іван Петренко", ContactEmail = "ivan@example.com" },
                new OwnerModel { Id = owner2Id, FullName = "Олена Коваленко", ContactEmail = "olena@example.com" }
            );

            modelBuilder.Entity<SmartphoneModel>().HasData(
                new SmartphoneModel
                {
                    Id = smartphoneId,
                    Manufacturer = "Samsung",
                    Model = "Galaxy S21",
                    Year = 2021,
                    Price = 800.00m,
                    OwnerId = owner1Id,
                    CameraMegapixels = 64,
                    ScreenSizeInches = 6.2
                }
            );

            modelBuilder.Entity<LaptopModel>().HasData(
                new LaptopModel
                {
                    Id = laptopId,
                    Manufacturer = "Apple",
                    Model = "MacBook Pro M1",
                    Year = 2020,
                    Price = 1500.00m,
                    OwnerId = owner2Id,
                    RamGB = 16,
                    ProcessorBrand = "Apple M1"
                }
            );

            modelBuilder.Entity<SpecificationModel>().HasData(
                new SpecificationModel { DeviceId = smartphoneId, OperatingSystem = "Android 14", BatteryLifeHours = 12.5 },
                new SpecificationModel { DeviceId = laptopId, OperatingSystem = "macOS Ventura", BatteryLifeHours = 18.0 }
            );
        }
    }
}