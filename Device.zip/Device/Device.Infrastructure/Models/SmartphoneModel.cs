﻿using System.ComponentModel.DataAnnotations.Schema;
using Devices.Infrastructure.Models;

namespace Devices.Infrastructure.Models
{
    [Table("Smartphones")]
    public class SmartphoneModel : DeviceModel
    {
        public int CameraMegapixels { get; set; }
        public double ScreenSizeInches { get; set; }
    }
}