﻿using System;

namespace Devices.Infrastructure.Models
{
    public class SpecificationModel
    {
        public Guid DeviceId { get; set; }
        public string OperatingSystem { get; set; }
        public double BatteryLifeHours { get; set; }

        public DeviceModel Device { get; set; }
    }

}