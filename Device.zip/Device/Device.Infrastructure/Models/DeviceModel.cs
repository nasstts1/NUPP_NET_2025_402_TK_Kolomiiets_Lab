﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Devices.Infrastructure.Models
{
    public abstract class DeviceModel
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;

        public string Manufacturer { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int Year { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        public Guid OwnerId { get; set; }
        public OwnerModel? Owner { get; set; }

        //public Guid? SpecificationId { get; set; }
    }
}
