﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 

namespace Devices.Infrastructure.Migrations
{
    public partial class Init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Owners",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    FullName = table.Column<string>(type: "TEXT", nullable: false),
                    ContactEmail = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Owners", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Devices",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Manufacturer = table.Column<string>(type: "TEXT", nullable: false),
                    Model = table.Column<string>(type: "TEXT", nullable: false),
                    Year = table.Column<int>(type: "INTEGER", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    OwnerId = table.Column<Guid>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Devices", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Devices_Owners_OwnerId",
                        column: x => x.OwnerId,
                        principalTable: "Owners",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Laptops",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    RamGB = table.Column<int>(type: "INTEGER", nullable: false),
                    ProcessorBrand = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Laptops", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Laptops_Devices_Id",
                        column: x => x.Id,
                        principalTable: "Devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Smartphones",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    CameraMegapixels = table.Column<int>(type: "INTEGER", nullable: false),
                    ScreenSizeInches = table.Column<double>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Smartphones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Smartphones_Devices_Id",
                        column: x => x.Id,
                        principalTable: "Devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Specifications",
                columns: table => new
                {
                    DeviceId = table.Column<Guid>(type: "TEXT", nullable: false),
                    OperatingSystem = table.Column<string>(type: "TEXT", nullable: false),
                    BatteryLifeHours = table.Column<double>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Specifications", x => x.DeviceId);
                    table.ForeignKey(
                        name: "FK_Specifications_Devices_DeviceId",
                        column: x => x.DeviceId,
                        principalTable: "Devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Owners",
                columns: new[] { "Id", "ContactEmail", "FullName" },
                values: new object[,]
                {
                    { new Guid("a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1"), "ivan@example.com", "Іван Петренко" },
                    { new Guid("b2b2b2b2-b2b2-42b2-b2b2-b2b2b2b2b2b2"), "olena@example.com", "Олена Коваленко" }
                });

            migrationBuilder.InsertData(
                table: "Devices",
                columns: new[] { "Id", "Manufacturer", "Model", "OwnerId", "Price", "Year" },
                values: new object[,]
                {
                    { new Guid("c3c3c3c3-c3c3-43c3-c3c3-c3c3c3c3c3c3"), "Samsung", "Galaxy S21", new Guid("a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1"), 800.00m, 2021 },
                    { new Guid("d4d4d4d4-d4d4-44d4-d4d4-d4d4d4d4d4d4"), "Apple", "MacBook Pro M1", new Guid("b2b2b2b2-b2b2-42b2-b2b2-b2b2b2b2b2b2"), 1500.00m, 2020 }
                });

            migrationBuilder.InsertData(
                table: "Laptops",
                columns: new[] { "Id", "ProcessorBrand", "RamGB" },
                values: new object[] { new Guid("d4d4d4d4-d4d4-44d4-d4d4-d4d4d4d4d4d4"), "Apple M1", 16 });

            migrationBuilder.InsertData(
                table: "Smartphones",
                columns: new[] { "Id", "CameraMegapixels", "ScreenSizeInches" },
                values: new object[] { new Guid("c3c3c3c3-c3c3-43c3-c3c3-c3c3c3c3c3c3"), 64, 6.2000000000000002 });

            migrationBuilder.InsertData(
                table: "Specifications",
                columns: new[] { "DeviceId", "BatteryLifeHours", "OperatingSystem" },
                values: new object[,]
                {
                    { new Guid("c3c3c3c3-c3c3-43c3-c3c3-c3c3c3c3c3c3"), 12.5, "Android 14" },
                    { new Guid("d4d4d4d4-d4d4-44d4-d4d4-d4d4d4d4d4d4"), 18.0, "macOS Ventura" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Devices_OwnerId",
                table: "Devices",
                column: "OwnerId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Laptops");

            migrationBuilder.DropTable(
                name: "Smartphones");

            migrationBuilder.DropTable(
                name: "Specifications");

            migrationBuilder.DropTable(
                name: "Devices");

            migrationBuilder.DropTable(
                name: "Owners");
        }
    }
}
