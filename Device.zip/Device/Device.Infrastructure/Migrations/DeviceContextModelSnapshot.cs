﻿using System;
using Devices.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

#nullable disable

namespace Devices.Infrastructure.Migrations
{
    [DbContext(typeof(DeviceContext))]
    partial class DeviceContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder.HasAnnotation("ProductVersion", "8.0.5");

            modelBuilder.Entity("Devices.Infrastructure.Models.DeviceModel", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("TEXT");

                    b.Property<string>("Manufacturer")
                        .IsRequired()
                        .HasColumnType("TEXT");

                    b.Property<string>("Model")
                        .IsRequired()
                        .HasColumnType("TEXT");

                    b.Property<Guid>("OwnerId")
                        .HasColumnType("TEXT");

                    b.Property<decimal>("Price")
                        .HasColumnType("decimal(18,2)");

                    b.Property<int>("Year")
                        .HasColumnType("INTEGER");

                    b.HasKey("Id");

                    b.HasIndex("OwnerId");

                    b.ToTable("Devices", (string)null);

                    b.UseTptMappingStrategy();
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.OwnerModel", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("TEXT");

                    b.Property<string>("ContactEmail")
                        .IsRequired()
                        .HasColumnType("TEXT");

                    b.Property<string>("FullName")
                        .IsRequired()
                        .HasColumnType("TEXT");

                    b.HasKey("Id");

                    b.ToTable("Owners");

                    b.HasData(
                        new
                        {
                            Id = new Guid("a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1"),
                            ContactEmail = "ivan@example.com",
                            FullName = "Іван Петренко"
                        },
                        new
                        {
                            Id = new Guid("b2b2b2b2-b2b2-42b2-b2b2-b2b2b2b2b2b2"),
                            ContactEmail = "olena@example.com",
                            FullName = "Олена Коваленко"
                        });
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.SpecificationModel", b =>
                {
                    b.Property<Guid>("DeviceId")
                        .HasColumnType("TEXT");

                    b.Property<double>("BatteryLifeHours")
                        .HasColumnType("REAL");

                    b.Property<string>("OperatingSystem")
                        .IsRequired()
                        .HasColumnType("TEXT");

                    b.HasKey("DeviceId");

                    b.ToTable("Specifications");

                    b.HasData(
                        new
                        {
                            DeviceId = new Guid("c3c3c3c3-c3c3-43c3-c3c3-c3c3c3c3c3c3"),
                            BatteryLifeHours = 12.5,
                            OperatingSystem = "Android 14"
                        },
                        new
                        {
                            DeviceId = new Guid("d4d4d4d4-d4d4-44d4-d4d4-d4d4d4d4d4d4"),
                            BatteryLifeHours = 18.0,
                            OperatingSystem = "macOS Ventura"
                        });
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.LaptopModel", b =>
                {
                    b.HasBaseType("Devices.Infrastructure.Models.DeviceModel");

                    b.Property<string>("ProcessorBrand")
                        .IsRequired()
                        .HasColumnType("TEXT");

                    b.Property<int>("RamGB")
                        .HasColumnType("INTEGER");

                    b.ToTable("Laptops", (string)null);

                    b.HasData(
                        new
                        {
                            Id = new Guid("d4d4d4d4-d4d4-44d4-d4d4-d4d4d4d4d4d4"),
                            Manufacturer = "Apple",
                            Model = "MacBook Pro M1",
                            OwnerId = new Guid("b2b2b2b2-b2b2-42b2-b2b2-b2b2b2b2b2b2"),
                            Price = 1500.00m,
                            Year = 2020,
                            ProcessorBrand = "Apple M1",
                            RamGB = 16
                        });
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.SmartphoneModel", b =>
                {
                    b.HasBaseType("Devices.Infrastructure.Models.DeviceModel");

                    b.Property<int>("CameraMegapixels")
                        .HasColumnType("INTEGER");

                    b.Property<double>("ScreenSizeInches")
                        .HasColumnType("REAL");

                    b.ToTable("Smartphones", (string)null);

                    b.HasData(
                        new
                        {
                            Id = new Guid("c3c3c3c3-c3c3-43c3-c3c3-c3c3c3c3c3c3"),
                            Manufacturer = "Samsung",
                            Model = "Galaxy S21",
                            OwnerId = new Guid("a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1"),
                            Price = 800.00m,
                            Year = 2021,
                            CameraMegapixels = 64,
                            ScreenSizeInches = 6.2000000000000002
                        });
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.DeviceModel", b =>
                {
                    b.HasOne("Devices.Infrastructure.Models.OwnerModel", "Owner")
                        .WithMany("Devices")
                        .HasForeignKey("OwnerId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Owner");
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.SpecificationModel", b =>
                {
                    b.HasOne("Devices.Infrastructure.Models.DeviceModel", "Device")
                        .WithOne()
                        .HasForeignKey("Devices.Infrastructure.Models.SpecificationModel", "DeviceId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Device");
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.LaptopModel", b =>
                {
                    b.HasOne("Devices.Infrastructure.Models.DeviceModel", null)
                        .WithOne()
                        .HasForeignKey("Devices.Infrastructure.Models.LaptopModel", "Id")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.SmartphoneModel", b =>
                {
                    b.HasOne("Devices.Infrastructure.Models.DeviceModel", null)
                        .WithOne()
                        .HasForeignKey("Devices.Infrastructure.Models.SmartphoneModel", "Id")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();
                });

            modelBuilder.Entity("Devices.Infrastructure.Models.OwnerModel", b =>
                {
                    b.Navigation("Devices");
                });
#pragma warning restore 612, 618
        }
    }
}
