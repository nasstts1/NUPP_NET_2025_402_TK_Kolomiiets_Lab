﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Devices.Common.Repositories
{
    public interface IRepository<T> where T : class
    {
        Task<T?> GetByIdAsync(Guid id);
        Task<IEnumerable<T>> GetAllAsync();
        Task<IEnumerable<T>> GetPagedAsync(int page, int amount); 
        Task AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task RemoveAsync(T entity); 

        Task SaveAsync();
    }
}
