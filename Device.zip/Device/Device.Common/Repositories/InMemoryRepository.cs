﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Devices.Common.Repositories
{
    public class InMemoryRepository<T> : IRepository<T> where T : class
    {
        private readonly List<T> _store = new();

        public Task AddAsync(T entity)
        {
            _store.Add(entity);
            return Task.CompletedTask;
        }

        public Task RemoveAsync(T entity)
        {
            _store.Remove(entity);
            return Task.CompletedTask;
        }

        public Task UpdateAsync(T entity)
        {
            // Для простоти нічого не робимо, оскільки об'єкти у списку вже за посиланням
            return Task.CompletedTask;
        }

        public Task<T?> GetByIdAsync(Guid id)
        {
            // Припускаємо, що у T є властивість Id типу Guid
            var prop = typeof(T).GetProperty("Id");
            if (prop == null) return Task.FromResult<T?>(null);

            var item = _store.FirstOrDefault(x => (Guid)prop.GetValue(x)! == id);
            return Task.FromResult(item);
        }

        public Task<IEnumerable<T>> GetAllAsync()
        {
            return Task.FromResult(_store.AsEnumerable());
        }

        public Task<IEnumerable<T>> GetPagedAsync(int page, int amount)
        {
            var items = _store.Skip((page - 1) * amount).Take(amount);
            return Task.FromResult(items);
        }

        public Task SaveAsync()
        {
            // Для InMemory нічого не робимо
            return Task.CompletedTask;
        }
    }
}
