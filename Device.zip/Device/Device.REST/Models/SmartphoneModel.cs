﻿namespace Device.REST.Models
{
    public class SmartphoneModel
    {
        public Guid Id { get; set; }
        public string Brand { get; set; } = string.Empty; // <- тут замість Manufacturer
        public string Model { get; set; } = string.Empty;
        public int Year { get; set; }
        public decimal Price { get; set; }
        public int CameraMegapixels { get; set; }
        public double ScreenSizeInches { get; set; }
    }
}

