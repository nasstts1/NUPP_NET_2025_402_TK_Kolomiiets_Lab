﻿public class CreateSmartphoneModel
{
    public Guid Id { get; set; }
    public string Brand { get; set; } = string.Empty;
    public string Model { get; set; } = string.Empty;
    public int Year { get; set; }
    public decimal Price { get; set; }
    public int CameraMegapixels { get; set; }
    public double ScreenSizeInches { get; set; }
}
