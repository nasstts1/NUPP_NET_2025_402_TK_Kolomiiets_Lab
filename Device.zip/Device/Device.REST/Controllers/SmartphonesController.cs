﻿using Device.REST.Models;
using Devices.Common;
using Devices.Common.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Device.REST.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SmartphonesController : ControllerBase
    {
        private readonly ICrudServiceAsync<SmartphoneModel> _service;

        public SmartphonesController(ICrudServiceAsync<SmartphoneModel> service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var phones = await _service.ReadAllAsync();
            return Ok(phones);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var phone = await _service.ReadAsync(id);
            if (phone == null) return NotFound();
            return Ok(phone);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateSmartphoneModel model)
        {
            var newPhone = new SmartphoneModel
            {
                Id = model.Id,
                Brand = model.Brand,
                Model = model.Model,
                Year = model.Year,
                Price = model.Price,
                CameraMegapixels = model.CameraMegapixels,
                ScreenSizeInches = model.ScreenSizeInches
            };

            await _service.CreateAsync(newPhone);
            await _service.SaveAsync();

            return CreatedAtAction(nameof(GetById), new { id = newPhone.Id }, newPhone);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] SmartphoneModel model)
        {
            model.Id = id;
            var updated = await _service.UpdateAsync(model);
            if (!updated) return NotFound();
            await _service.SaveAsync();
            return Ok(model);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var phone = await _service.ReadAsync(id);
            if (phone == null) return NotFound();
            await _service.RemoveAsync(phone);
            await _service.SaveAsync();
            return NoContent();
        }
    }
}


