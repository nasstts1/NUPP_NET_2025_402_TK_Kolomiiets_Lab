﻿using Device.REST.Models;
using Devices.Common;
using Devices.Common.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Device.REST.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LaptopsController : ControllerBase
    {
        private readonly ICrudServiceAsync<LaptopModel> _service;

        public LaptopsController(ICrudServiceAsync<LaptopModel> service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var laptops = await _service.ReadAllAsync();
            return Ok(laptops);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var laptop = await _service.ReadAsync(id);
            if (laptop == null) return NotFound();
            return Ok(laptop);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateLaptopModel model)
        {
            var newLaptop = new LaptopModel
            {
                Id = model.Id,
                Brand = model.Brand,
                Model = model.Model,
                Year = model.Year,
                Price = model.Price
            };

            await _service.CreateAsync(newLaptop);
            await _service.SaveAsync();

            return CreatedAtAction(nameof(GetById), new { id = newLaptop.Id }, newLaptop);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] LaptopModel model)
        {
            model.Id = id;
            var updated = await _service.UpdateAsync(model);
            if (!updated) return NotFound();
            await _service.SaveAsync();
            return Ok(model);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var laptop = await _service.ReadAsync(id);
            if (laptop == null) return NotFound();
            await _service.RemoveAsync(laptop);
            await _service.SaveAsync();
            return NoContent();
        }
    }
}
