using Device.REST.Models;
using Devices.Common;
using Devices.Common.Repositories;
using Devices.Common.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddSingleton<IRepository<SmartphoneModel>, InMemoryRepository<SmartphoneModel>>();
builder.Services.AddSingleton<IRepository<LaptopModel>, InMemoryRepository<LaptopModel>>();

builder.Services.AddScoped<ICrudServiceAsync<SmartphoneModel>, CrudServiceAsync<SmartphoneModel>>();
builder.Services.AddScoped<ICrudServiceAsync<LaptopModel>, CrudServiceAsync<LaptopModel>>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
