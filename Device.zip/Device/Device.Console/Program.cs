﻿using Devices.Common.Repositories;
using Devices.Common.Services;
using Devices.Infrastructure;
using Devices.Infrastructure.Models;
using Devices.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

var builder = Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddLogging(logging =>
        {
            logging.ClearProviders(); 
            logging.AddConsole();
            logging.SetMinimumLevel(LogLevel.Warning); 
        });

        services.AddDbContext<DeviceContext>(options =>
            options.UseInMemoryDatabase("DevicesDB"),
            ServiceLifetime.Scoped);

        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

        services.AddScoped(typeof(ICrudServiceAsync<>), typeof(CrudServiceAsync<>));
    })
    .Build();

try
{
    Console.WriteLine("=== CRUD Operations on Devices (Clean Architecture) ===");

    Guid newDeviceId;

    using (var scope = builder.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        var smartphoneService = services.GetRequiredService<ICrudServiceAsync<SmartphoneModel>>();
        var context = services.GetRequiredService<DeviceContext>();
        await context.Database.EnsureCreatedAsync();

        var newSmartphone = new SmartphoneModel
        {
            Id = Guid.NewGuid(),
            Manufacturer = "Apple",
            Model = "iPhone 15",
            Year = 2023,
            Price = 1200.00m,
            Name = "iPhone 15",
            Type = "Smartphone",
            OwnerId = context.Owners.First().Id,
            CameraMegapixels = 48,
            ScreenSizeInches = 6.1
        };

        newDeviceId = newSmartphone.Id;

        Console.WriteLine($"\n[C] Creating a device: {newSmartphone.Manufacturer} {newSmartphone.Model}");
        await smartphoneService.CreateAsync(newSmartphone);
        await smartphoneService.SaveAsync(); 
    }

    using (var scope = builder.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        var smartphoneService = services.GetRequiredService<ICrudServiceAsync<SmartphoneModel>>();
        var context = services.GetRequiredService<DeviceContext>();

        // --- READ ALL ---
        var devices = await smartphoneService.ReadAllAsync();

        Console.WriteLine("\n[R] --- All smartphones in the database (including Seeding) ---");
        foreach (var d in devices)
        {
            Console.WriteLine($"- ID: {d.Id.ToString().Substring(0, 8)}... | {d.Manufacturer} {d.Model} | Cell: {d.CameraMegapixels} Mp");
        }

        // --- UPDATE ---
        var first = devices.FirstOrDefault(d => d.Id == newDeviceId);

        if (first != null)
        {
            var oldModel = first.Model;
            first.Model = "iPhone 15 Pro (update)";
            Console.WriteLine($"\n[U] Device update {first.Id.ToString().Substring(0, 8)}... ({oldModel} -> {first.Model})");

            await smartphoneService.UpdateAsync(first);
            await smartphoneService.SaveAsync();
        }

        // --- DELETE ---
        if (first != null)
        {
            Console.WriteLine($"\n[D] Removing the device {first.Id.ToString().Substring(0, 8)}... ({first.Model})");
            await smartphoneService.RemoveAsync(first);
            await smartphoneService.SaveAsync();
        }

        // --- FINAL READ ---
        var afterDelete = await smartphoneService.ReadAllAsync();
        Console.WriteLine($"\n[R] --- Number of smartphones after removal: {afterDelete.Count()} ---");
    }

    Console.WriteLine("\n=== Demonstration completed successfully. ===");
}
catch (Exception ex)
{
    Console.WriteLine($"\nCritical execution error: {ex.Message}");
    Console.WriteLine($"stack: {ex.StackTrace}");
}

Environment.Exit(0);
